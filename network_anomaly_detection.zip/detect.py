import pandas as pd
import joblib

model = joblib.load("rf_model.joblib")
df = pd.read_csv("out.csv")
predictions = model.predict(df)

with open("alerts_log.txt", "w") as f:
    for i, pred in enumerate(predictions):
        if pred == 1:
            f.write(f"⚠️ Alert: Anomaly detected at row {i}\n")
