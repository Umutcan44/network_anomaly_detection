import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import joblib

model = joblib.load("rf_model.joblib")

def detect_anomalies():
    try:
        filepath = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        df = pd.read_csv(filepath)
        predictions = model.predict(df)

        with open("alerts_log.txt", "w") as f:
            for i, pred in enumerate(predictions):
                if pred == 1:
                    f.write(f"⚠️ Alert: Anomaly detected at row {i}\n")

        messagebox.showinfo("Detection Complete", "Alerts saved to alerts_log.txt")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("Network Anomaly Detection")
root.geometry("400x200")

tk.Label(root, text="Network Anomaly Detection", font=("Arial", 14)).pack(pady=10)
tk.Button(root, text="Select CSV File and Detect", command=detect_anomalies).pack(pady=10)

root.mainloop()
